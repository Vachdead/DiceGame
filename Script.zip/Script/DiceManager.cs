﻿using UnityEngine;
using System.Collections;

// Dice Holder for Game Object
public class DiceManager : MonoBehaviour
{
    public Dice dice;   
}
